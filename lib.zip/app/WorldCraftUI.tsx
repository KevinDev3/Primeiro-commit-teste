'use client';
import RichTextEditor from '../components/RichTextEditor';
import RelationsPanel from '../components/RelationsPanel'; // Adicione esta linha
import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { WorldProvider, useWorldContext } from './context/WorldContext';
import Sidebar, { wikiCategories } from '../components/Sidebar';
import EntityList from '../components/EntityList';
import EntitySheet from '../components/EntitySheet';
import CreateEntityModal from '../components/Modals/CreateEntityModal';
import CreateWorldModal from '../components/Modals/CreateWorldModal';
import { Sparkles, Plus, User } from 'lucide-react';

// ─────────────────────────────────────────────────────────────
// Dashboard
// ─────────────────────────────────────────────────────────────
function DashboardView({ onCreateWorld }: { onCreateWorld: () => void }) {
  return (
    <div className="h-full flex flex-col items-center justify-center p-8 animate-in fade-in duration-300">
      <Sparkles className="w-16 h-16 text-emerald-500/20 mb-6" />
      <h2 className="text-4xl font-serif text-white mb-3">Visão Geral</h2>
      <p className="text-slate-500 mb-8 text-center max-w-sm">
        Crie e gerencie seus universos de ficção, campanhas e worldbuilding.
      </p>
      <button
        onClick={onCreateWorld}
        className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold px-6 py-3 rounded-lg transition-all shadow-[0_0_20px_rgba(16,185,129,0.4)]"
      >
        <Plus className="w-5 h-5" /> Criar Novo Mundo
      </button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Wiki
// ─────────────────────────────────────────────────────────────
function WikiView({ onCreateEntity, setActiveView }: {
  onCreateEntity: () => void;
  setActiveView: (v: string) => void;
}) {
  const { selectedWorld, wikiCounts } = useWorldContext();
  return (
    <div className="h-full flex flex-col p-8 animate-in fade-in duration-300 max-w-7xl mx-auto w-full">
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-4xl font-serif font-bold text-white mb-2">Wiki</h1>
          <p className="text-slate-400 text-lg">Enciclopédia de {selectedWorld?.name || 'AWP'}</p>
        </div>
        <button
          onClick={onCreateEntity}
          className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold px-5 py-2.5 rounded-lg shadow-[0_0_15px_rgba(16,185,129,0.3)] transition-all"
        >
          <Plus className="w-5 h-5" /> Nova Entidade
        </button>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
        {wikiCategories.map(cat => (
          <button
            key={cat.key}
            onClick={() => setActiveView(cat.id)}
            className="bg-[#0B1018] border border-slate-800 hover:border-emerald-500/40 rounded-xl p-4 text-left transition-all group hover:bg-slate-800/50"
          >
            <cat.icon className="w-6 h-6 text-slate-500 group-hover:text-emerald-400 mb-3 transition-colors" />
            <p className="text-slate-200 font-medium text-sm group-hover:text-white">{cat.label}</p>
            <p className="text-3xl font-serif text-white mt-1">{wikiCounts[cat.key as keyof typeof wikiCounts] || 0}</p>
            <p className="text-[10px] text-slate-600 mt-1 truncate">{cat.desc}</p>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Personagens
// ─────────────────────────────────────────────────────────────
function PersonagensView({ onCreateEntity }: { onCreateEntity: () => void }) {
  return (
    <div className="h-full flex flex-col lg:flex-row p-6 gap-6 animate-in fade-in duration-300">
      <EntityList onCreateEntity={onCreateEntity} />
      <EntitySheet />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Coming Soon (other categories)
// ─────────────────────────────────────────────────────────────
function ComingSoonView({ label }: { label: string }) {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center p-8 animate-in fade-in duration-300">
      <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center mb-4 border border-emerald-500/20">
        <Sparkles className="w-8 h-8 text-emerald-500/40" />
      </div>
      <h2 className="text-2xl font-serif text-white mb-2">{label}</h2>
      <p className="text-slate-500 text-sm max-w-xs">
        Essa seção está em desenvolvimento. Em breve você poderá gerir todas as entidades deste tipo.
      </p>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Inner app (needs to be inside WorldProvider to use context)
// ─────────────────────────────────────────────────────────────
function AppInner({ session }: { session?: any }) {
  const [activeView, setActiveView] = useState('wiki');
  const [isWikiOpen, setIsWikiOpen] = useState(true);
  const [isWorldModalOpen, setIsWorldModalOpen] = useState(false);
  const [isEntityModalOpen, setIsEntityModalOpen] = useState(false);
  const [entityModalDefaultType, setEntityModalDefaultType] = useState<any>(null);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    window.location.reload();
  };

  const openEntityModal = (defaultType?: any) => {
    setEntityModalDefaultType(defaultType ?? null);
    setIsEntityModalOpen(true);
  };

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return <DashboardView onCreateWorld={() => setIsWorldModalOpen(true)} />;
      case 'wiki':
        return <WikiView onCreateEntity={() => openEntityModal()} setActiveView={setActiveView} />;
      case 'personagens':
        return <PersonagensView onCreateEntity={() => openEntityModal(wikiCategories.find(c => c.key === 'Personagem'))} />;
      default: {
        const cat = wikiCategories.find(c => c.id === activeView);
        return <ComingSoonView label={cat?.label ?? activeView} />;
      }
    }
  };

  return (
    <div className="flex h-screen bg-[#090D14] text-slate-300 font-sans overflow-hidden">
      <Sidebar
        activeView={activeView}
        setActiveView={setActiveView}
        isWikiOpen={isWikiOpen}
        setIsWikiOpen={setIsWikiOpen}
        onCreateWorld={() => setIsWorldModalOpen(true)}
        onLogout={handleLogout}
      />

      <main className="flex-1 flex flex-col relative overflow-hidden">
        <header className="h-14 border-b border-slate-800/50 flex items-center justify-between px-6 bg-[#090D14]/80 backdrop-blur-md z-10 shrink-0">
          <span className="text-xs text-slate-600 uppercase tracking-widest font-mono">
            {wikiCategories.find(c => c.id === activeView)?.label ?? activeView}
          </span>
          <div className="h-8 px-3 rounded-full bg-slate-800 border border-slate-700 flex items-center gap-2">
            <User className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-xs text-slate-300">{session?.user?.email}</span>
          </div>
        </header>

        <div className="flex-1 overflow-auto relative custom-scrollbar">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-emerald-500/5 rounded-full blur-[120px] pointer-events-none" />
          {renderContent()}
        </div>
      </main>

      <CreateWorldModal isOpen={isWorldModalOpen} onClose={() => setIsWorldModalOpen(false)} />
      <CreateEntityModal
        isOpen={isEntityModalOpen}
        onClose={() => setIsEntityModalOpen(false)}
        onCreated={() => setActiveView('personagens')}
        defaultType={entityModalDefaultType}
      />

      <style dangerouslySetInnerHTML={{ __html: `.custom-scrollbar::-webkit-scrollbar{height:4px;width:4px}.custom-scrollbar::-webkit-scrollbar-track{background:transparent}.custom-scrollbar::-webkit-scrollbar-thumb{background-color:#1e293b;border-radius:20px}` }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// ROOT EXPORT — wraps everything in the provider
// ─────────────────────────────────────────────────────────────
export default function WorldCraftUI({ session }: { session?: any }) {
  return (
    <WorldProvider session={session}>
      <AppInner session={session} />
    </WorldProvider>
  );
}
