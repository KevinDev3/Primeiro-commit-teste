'use client';

import React, { createContext, useContext, useState, useEffect, useCallback, useRef, ReactNode } from 'react';
import { supabase } from '../../lib/supabase';

// --- INTERFACES ---
export interface IWorld { id: string; name: string; description?: string; }
export interface ICharacter { id: string; name: string; biography: string; avatar_url: string; role: string; race?: string; class_name?: string; }
export type WikiCounts = { Conceito: number; Criatura: number; Divindade: number; Evento: number; Item: number; Local: number; Organização: number; Personagem: number; Raças: number; };

interface WorldContextType {
  session: any;
  worlds: IWorld[];
  selectedWorld: IWorld | null;
  setSelectedWorld: (world: IWorld) => void;
  fetchWorlds: () => Promise<void>;
  handleCreateWorld: (name: string) => Promise<void>;
  characters: ICharacter[];
  selectedCharacter: string | null;
  currentCharacterData: ICharacter | undefined;
  charBio: string;
  setCharBio: (bio: string) => void;
  avatarUrl: string | null;
  setAvatarUrl: (url: string | null) => void;
  wikiCounts: WikiCounts;
  loadCharacterData: (char: ICharacter) => void;
  handleSaveCharacterInfo: () => Promise<void>;
  handleAvatarUpload: (e: React.ChangeEvent<HTMLInputElement>) => Promise<void>;
  handleCreateEntity: (name: string, type: string, mode: 'livre' | 'molde') => Promise<ICharacter | null>;
  isSavingChar: boolean;
  isUploading: boolean;
  fileInputRef: React.RefObject<HTMLInputElement>;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  filteredCharacters: ICharacter[];
}

const WorldContext = createContext<WorldContextType | null>(null);

export const useWorldContext = () => {
  const ctx = useContext(WorldContext);
  if (!ctx) throw new Error('useWorldContext must be used inside WorldProvider');
  return ctx;
};

const TEMPLATE_PERSONAGEM = `
  <h2>Descrição Física</h2>
  <p>Aparência, cicatrizes marcantes, estilo de roupa e postura típica...</p>
  <h2>História e Antecedentes</h2>
  <p>De onde veio? Quais os grandes eventos do seu passado?</p>
  <h2>Personalidade e Ideais</h2>
  <p>Maiores medos, virtudes e o que defende cegamente?</p>
`;
const TEMPLATE_LIVRE = `<p>Comece a escrever a lore aqui...</p>`;

export function WorldProvider({ session, children }: { session: any; children: ReactNode }) {
  const [worlds, setWorlds] = useState<IWorld[]>([]);
  const [selectedWorld, setSelectedWorld] = useState<IWorld | null>(null);
  const [characters, setCharacters] = useState<ICharacter[]>([]);
  const [selectedCharacter, setSelectedCharacter] = useState<string | null>(null);
  const [charBio, setCharBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [isSavingChar, setIsSavingChar] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [wikiCounts, setWikiCounts] = useState<WikiCounts>({
    Conceito: 0, Criatura: 0, Divindade: 0, Evento: 0,
    Item: 0, Local: 0, Organização: 0, Personagem: 0, Raças: 0,
  });
  const fileInputRef = useRef<HTMLInputElement>(null!);

  useEffect(() => { fetchWorlds(); }, []);
  useEffect(() => { if (selectedWorld) fetchCharacters(selectedWorld.id); }, [selectedWorld]);

  const fetchWorlds = useCallback(async () => {
    const { data, error } = await supabase.from('worlds').select('*').order('created_at', { ascending: false });
    if (!error && data) {
      setWorlds(data);
      if (data.length > 0) setSelectedWorld(prev => prev ?? data[0]);
    }
  }, []);

  const fetchCharacters = useCallback(async (worldId: string) => {
    const { data, error } = await supabase.from('characters').select('*').eq('world_id', worldId).order('created_at', { ascending: false });
    if (!error && data) {
      setCharacters(data);
      setWikiCounts(prev => ({ ...prev, Personagem: data.length }));
      if (data.length > 0) loadCharacterData(data[0]);
      else { setSelectedCharacter(null); setCharBio(''); setAvatarUrl(null); }
    }
  }, []);

  const loadCharacterData = useCallback((char: ICharacter) => {
    setSelectedCharacter(char.id);
    setCharBio(char.biography || '');
    setAvatarUrl(char.avatar_url || null);
  }, []);

  const handleCreateWorld = useCallback(async (name: string) => {
    const { data, error } = await supabase.from('worlds').insert([{ name }]).select();
    if (error) throw error;
    await fetchWorlds();
    if (data) setSelectedWorld(data[0]);
  }, [fetchWorlds]);

  const handleCreateEntity = useCallback(async (name: string, type: string, mode: 'livre' | 'molde'): Promise<ICharacter | null> => {
    if (!selectedWorld) throw new Error('Selecione um mundo.');
    const initialBio = mode === 'molde' && type === 'Personagem' ? TEMPLATE_PERSONAGEM : TEMPLATE_LIVRE;
    const { data, error } = await supabase.from('characters').insert([{
      world_id: selectedWorld.id, name, biography: initialBio, role: 'NPC',
    }]).select();
    if (error) throw error;
    await fetchCharacters(selectedWorld.id);
    if (data && data[0]) { loadCharacterData(data[0]); return data[0]; }
    return null;
  }, [selectedWorld, fetchCharacters, loadCharacterData]);

  const handleSaveCharacterInfo = useCallback(async () => {
    if (!selectedCharacter) return;
    setIsSavingChar(true);
    try {
      const { error } = await supabase.from('characters').update({ biography: charBio, avatar_url: avatarUrl }).eq('id', selectedCharacter);
      if (error) throw error;
    } finally { setIsSavingChar(false); }
  }, [selectedCharacter, charBio, avatarUrl]);

  const handleAvatarUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    try {
      setIsUploading(true);
      const file = e.target.files?.[0];
      if (!file) return;
      const fileExt = file.name.split('.').pop();
      const filePath = `${session?.user?.id}/${Math.random()}.${fileExt}`;
      const { error: uploadError } = await supabase.storage.from('avatars').upload(filePath, file);
      if (uploadError) throw uploadError;
      const { data } = supabase.storage.from('avatars').getPublicUrl(filePath);
      setAvatarUrl(data.publicUrl);
    } catch (error: any) {
      alert('Erro no upload: ' + error.message);
    } finally { setIsUploading(false); }
  }, [session]);

  const filteredCharacters = characters.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (c.role?.toLowerCase() ?? '').includes(searchQuery.toLowerCase())
  );

  const currentCharacterData = characters.find(c => c.id === selectedCharacter);

  return (
    <WorldContext.Provider value={{
      session, worlds, selectedWorld, setSelectedWorld, fetchWorlds, handleCreateWorld,
      characters, selectedCharacter, currentCharacterData, charBio, setCharBio,
      avatarUrl, setAvatarUrl, wikiCounts, loadCharacterData, handleSaveCharacterInfo,
      handleAvatarUpload, handleCreateEntity, isSavingChar, isUploading, fileInputRef,
      searchQuery, setSearchQuery, filteredCharacters,
    }}>
      {children}
    </WorldContext.Provider>
  );
}
