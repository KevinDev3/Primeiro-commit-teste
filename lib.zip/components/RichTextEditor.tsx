import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import { Bold, Italic, Strikethrough, List, ListOrdered, Heading2 } from 'lucide-react';
import { useEffect } from 'react';

interface RichTextEditorProps {
  initialContent?: string;
  onChange?: (content: string) => void;
}

export default function RichTextEditor({ initialContent, onChange }: RichTextEditorProps) {
  const editor = useEditor({
    extensions: [StarterKit],
    content: initialContent || '<p>Comece a escrever a história aqui...</p>',
    immediatelyRender: false,
    editorProps: {
      attributes: {
        class: 'prose prose-invert prose-emerald max-w-none focus:outline-none min-h-[250px] text-slate-300 pb-10',
      },
    },
    onUpdate: ({ editor }) => {
      if (onChange) onChange(editor.getHTML());
    },
  });

  // Garante que o editor atualiza se o initialContent mudar externamente (ao trocar de personagem)
  useEffect(() => {
    if (editor && initialContent !== editor.getHTML()) {
      editor.commands.setContent(initialContent || '');
    }
  }, [initialContent, editor]);

  if (!editor) return null;

  return (
    <div className="bg-slate-900/30 border border-slate-800 rounded-xl overflow-hidden focus-within:border-emerald-500/50 transition-all">
      <div className="flex items-center gap-1 p-2 border-b border-slate-800 bg-slate-900/80 sticky top-0 z-10">
        <button onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()} className={`p-1.5 rounded hover:bg-slate-800 transition-colors ${editor.isActive('heading', { level: 2 }) ? 'text-emerald-400 bg-slate-800' : 'text-slate-400'}`}><Heading2 className="w-4 h-4" /></button>
        <div className="w-px h-4 bg-slate-700 mx-1"></div>
        <button onClick={() => editor.chain().focus().toggleBold().run()} className={`p-1.5 rounded hover:bg-slate-800 transition-colors ${editor.isActive('bold') ? 'text-emerald-400 bg-slate-800' : 'text-slate-400'}`}><Bold className="w-4 h-4" /></button>
        <button onClick={() => editor.chain().focus().toggleItalic().run()} className={`p-1.5 rounded hover:bg-slate-800 transition-colors ${editor.isActive('italic') ? 'text-emerald-400 bg-slate-800' : 'text-slate-400'}`}><Italic className="w-4 h-4" /></button>
        <button onClick={() => editor.chain().focus().toggleStrike().run()} className={`p-1.5 rounded hover:bg-slate-800 transition-colors ${editor.isActive('strike') ? 'text-emerald-400 bg-slate-800' : 'text-slate-400'}`}><Strikethrough className="w-4 h-4" /></button>
        <div className="w-px h-4 bg-slate-700 mx-1"></div>
        <button onClick={() => editor.chain().focus().toggleBulletList().run()} className={`p-1.5 rounded hover:bg-slate-800 transition-colors ${editor.isActive('bulletList') ? 'text-emerald-400 bg-slate-800' : 'text-slate-400'}`}><List className="w-4 h-4" /></button>
        <button onClick={() => editor.chain().focus().toggleOrderedList().run()} className={`p-1.5 rounded hover:bg-slate-800 transition-colors ${editor.isActive('orderedList') ? 'text-emerald-400 bg-slate-800' : 'text-slate-400'}`}><ListOrdered className="w-4 h-4" /></button>
      </div>
      <div className="p-5">
        <EditorContent editor={editor} />
      </div>
    </div>
  );
}