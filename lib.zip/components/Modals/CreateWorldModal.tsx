'use client';

import React, { useState } from 'react';
import { X, Wand2, Loader2 } from 'lucide-react';
import { useWorldContext } from '../../app/context/WorldContext';

interface CreateWorldModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CreateWorldModal({ isOpen, onClose }: CreateWorldModalProps) {
  const { handleCreateWorld } = useWorldContext();
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await handleCreateWorld(name);
      setName('');
      onClose();
    } catch (err: any) {
      alert('Erro: ' + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#05080c]/80 backdrop-blur-sm">
      <div className="bg-[#0B1018] border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-serif text-white flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-emerald-400" />
            Forjar Mundo
          </h3>
          <button onClick={onClose} className="text-slate-500 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-500 tracking-wider uppercase mb-2 block">Nome do Universo</label>
            <input
              type="text"
              required
              autoFocus
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="O Grande Império de Valdran..."
              className="w-full bg-slate-900/50 border border-slate-800 focus:border-emerald-500/50 text-white rounded-lg px-4 py-3 focus:outline-none transition-all"
            />
          </div>
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-all shadow-[0_0_15px_rgba(16,185,129,0.3)] disabled:opacity-50"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Wand2 className="w-4 h-4" /> Criar Mundo</>}
          </button>
        </form>
      </div>
    </div>
  );
}
