'use client';

import React, { useState } from 'react';
import {
  X, ArrowLeft, Loader2, PenTool, LayoutTemplate,
  Wand2, Calendar, Diamond, Building2, Map, Share2, User, Lightbulb, Bug,
} from 'lucide-react';
import { useWorldContext } from '../../app/context/WorldContext';

const wikiCategories = [
  { id: 'conceitos', label: 'Conceito', icon: Lightbulb, key: 'Conceito', desc: 'Leis mágicas, teorias, dogmas' },
  { id: 'criaturas', label: 'Criatura', icon: Bug, key: 'Criatura', desc: 'Monstros, feras, bestas' },
  { id: 'divindades', label: 'Divindade', icon: Wand2, key: 'Divindade', desc: 'Deuses, panteões' },
  { id: 'eventos', label: 'Evento', icon: Calendar, key: 'Evento', desc: 'Guerras, cataclismas' },
  { id: 'itens', label: 'Item', icon: Diamond, key: 'Item', desc: 'Artefatos, relíquias' },
  { id: 'locais', label: 'Local', icon: Map, key: 'Local', desc: 'Reinos, cidades, masmorras' },
  { id: 'organizacoes', label: 'Organização', icon: Building2, key: 'Organização', desc: 'Guildas, reinos, cultos' },
  { id: 'personagens', label: 'Personagem', icon: User, key: 'Personagem', desc: 'Raça, Idade, Classe, Status' },
  { id: 'racas', label: 'Raças', icon: Share2, key: 'Raças', desc: 'Elfos, anões, humanos' },
];

type WikiCategory = typeof wikiCategories[0];

interface CreateEntityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated: () => void;
  defaultType?: WikiCategory | null;
}

export default function CreateEntityModal({ isOpen, onClose, onCreated, defaultType }: CreateEntityModalProps) {
  const { handleCreateEntity } = useWorldContext();
  const [step, setStep] = useState(defaultType ? 2 : 1);
  const [selectedType, setSelectedType] = useState<WikiCategory | null>(defaultType ?? null);
  const [name, setName] = useState('');
  const [mode, setMode] = useState<'livre' | 'molde'>('molde');
  const [isLoading, setIsLoading] = useState(false);

  const reset = () => {
    setStep(defaultType ? 2 : 1);
    setSelectedType(defaultType ?? null);
    setName('');
    setMode('molde');
  };

  const handleClose = () => { reset(); onClose(); };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedType) return;
    setIsLoading(true);
    try {
      await handleCreateEntity(name, selectedType.key, mode);
      handleClose();
      onCreated();
    } catch (err: any) {
      alert('Erro: ' + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#05080c]/80 backdrop-blur-sm">
      <div className="bg-[#0B1018] border border-slate-800 rounded-2xl w-full max-w-xl shadow-2xl p-6 relative overflow-hidden">

        {/* Step 1: Choose type */}
        {step === 1 && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-2xl font-serif text-white">Tipo de Entidade</h3>
                <p className="text-slate-500 text-sm mt-1">Escolha a categoria desta entrada na Wiki</p>
              </div>
              <button onClick={handleClose} className="text-slate-500 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-all">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-2.5">
              {wikiCategories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => { setSelectedType(cat); setStep(2); }}
                  className="flex flex-col items-center justify-center p-4 rounded-xl border border-slate-800 bg-[#090D14] hover:bg-slate-800 hover:border-emerald-500/50 gap-2.5 group transition-all"
                >
                  <cat.icon className="w-6 h-6 text-slate-400 group-hover:text-emerald-400 transition-colors" />
                  <div className="text-center">
                    <span className="text-sm text-slate-300 font-medium group-hover:text-white transition-colors block">{cat.label}</span>
                    <span className="text-[10px] text-slate-600 leading-tight">{cat.desc}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 2: Name + mode */}
        {step === 2 && selectedType && (
          <div>
            <div className="flex items-center gap-3 mb-6 border-b border-slate-800/50 pb-5">
              {!defaultType && (
                <button onClick={() => setStep(1)} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              )}
              <div className="flex items-center gap-2">
                <selectedType.icon className="w-5 h-5 text-emerald-400" />
                <h3 className="text-2xl font-serif text-white">Nova Entidade</h3>
                <span className="text-slate-500 text-sm font-sans">({selectedType.label})</span>
              </div>
              <button onClick={handleClose} className="ml-auto text-slate-500 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-all">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="mb-6">
                <label className="text-xs font-bold text-slate-500 tracking-wider uppercase mb-2 block">Nome</label>
                <input
                  type="text"
                  required
                  autoFocus
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder={`Nome do(a) ${selectedType.label.toLowerCase()}...`}
                  className="w-full bg-[#090D14] border border-emerald-500/30 focus:border-emerald-500 text-white text-lg rounded-xl px-5 py-4 focus:outline-none transition-all"
                />
              </div>

              <div className="mb-8">
                <label className="text-xs font-bold text-slate-500 tracking-wider uppercase mb-3 block">Formato de Criação</label>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { value: 'livre' as const, label: 'Criação Livre', desc: 'Página em branco para você', icon: PenTool },
                    { value: 'molde' as const, label: 'Usar Molde', desc: 'Template pré-estruturado', icon: LayoutTemplate },
                  ].map(opt => (
                    <div
                      key={opt.value}
                      onClick={() => setMode(opt.value)}
                      className={`cursor-pointer p-4 rounded-xl border flex flex-col gap-2 transition-all ${mode === opt.value
                        ? 'bg-slate-800/80 border-emerald-500 shadow-[inset_0_0_20px_rgba(16,185,129,0.05)]'
                        : 'bg-[#090D14] border-slate-800 hover:border-slate-700'}`}
                    >
                      <opt.icon className={`w-5 h-5 ${mode === opt.value ? 'text-emerald-400' : 'text-slate-500'}`} />
                      <span className={`font-medium text-sm ${mode === opt.value ? 'text-white' : 'text-slate-400'}`}>{opt.label}</span>
                      <span className="text-[11px] text-slate-600">{opt.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex justify-center items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-4 rounded-xl disabled:opacity-50 transition-all shadow-[0_0_20px_rgba(16,185,129,0.2)]"
              >
                {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Criar e Editar'}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
