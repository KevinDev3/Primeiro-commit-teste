'use client';

import React, { useState, useEffect } from 'react';
import { Plus, X, User, Loader2, ArrowRight, ArrowLeft, Link2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

// Interfaces
export interface IRelation {
  id: string;
  from_entity_id: string;
  to_entity_id: string;
  relation_label: string;
  world_id: string;
  from_entity?: { id: string; name: string; avatar_url: string; role: string; };
  to_entity?: { id: string; name: string; avatar_url: string; role: string; };
}

const RELATION_SUGGESTIONS = [
  'pertence a', 'governa', 'serve', 'é aliado de', 'é inimigo de',
  'criou', 'foi criado por', 'protege', 'traiu', 'conhece',
  'é lar de', 'foi forjado por', 'pertence ao panteão de',
  'é filho(a) de', 'lidera', 'é membro de',
];

interface RelationsPanelProps {
  selectedCharacter: string | null;
  selectedWorld: any;
  characters: any[];
  session: any;
}

export default function RelationsPanel({ selectedCharacter, selectedWorld, characters, session }: RelationsPanelProps) {
  const [relations, setRelations] = useState<IRelation[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [label, setLabel] = useState('');
  const [targetId, setTargetId] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    if (selectedCharacter) {
      fetchRelations();
    } else {
      setRelations([]);
    }
  }, [selectedCharacter]);

  const fetchRelations = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from('entity_relations')
      .select(`
        *,
        from_entity:characters!from_entity_id(id, name, avatar_url, role),
        to_entity:characters!to_entity_id(id, name, avatar_url, role)
      `)
      .or(`from_entity_id.eq.${selectedCharacter},to_entity_id.eq.${selectedCharacter}`)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setRelations(data);
    }
    setIsLoading(false);
  };

  const handleCreate = async () => {
    if (!label.trim() || !targetId || !selectedCharacter || !selectedWorld) return;
    setIsCreating(true);
    
    try {
      const { error } = await supabase.from('entity_relations').insert([{
        world_id: selectedWorld.id,
        from_entity_id: selectedCharacter,
        to_entity_id: targetId,
        relation_label: label.trim(),
        owner_id: session?.user?.id,
      }]);

      if (error) throw error;
      
      await fetchRelations();
      setLabel('');
      setTargetId('');
      setShowForm(false);
    } catch (err: any) {
      alert('Erro ao criar relação: ' + err.message);
    } finally {
      setIsCreating(false);
    }
  };

  const handleDelete = async (id: string) => {
    setRelations(prev => prev.filter(r => r.id !== id)); // Atualização otimista
    const { error } = await supabase.from('entity_relations').delete().eq('id', id);
    if (error) {
      alert('Erro ao remover relação.');
      fetchRelations(); // Reverte em caso de erro
    }
  };

  if (!selectedCharacter) return null;

  const otherEntities = characters.filter(c => c.id !== selectedCharacter);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <p className="text-[10px] font-bold text-slate-500 tracking-wider uppercase flex items-center gap-1.5">
          <Link2 className="w-3.5 h-3.5" /> Conexões
        </p>
        <button 
          onClick={() => setShowForm(!showForm)} 
          className="text-slate-500 hover:text-white transition-colors"
          title="Nova Conexão"
        >
          {showForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
        </button>
      </div>

      {/* Formulário de Criação */}
      {showForm && (
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4 animate-in fade-in slide-in-from-top-2 flex flex-col gap-3">
          <div>
            <label className="text-xs font-medium text-slate-400 mb-1 block">Entidade Destino</label>
            <select 
              value={targetId} 
              onChange={(e) => setTargetId(e.target.value)}
              className="w-full bg-[#090D14] border border-slate-700 text-slate-300 text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-emerald-500/50 transition-colors"
            >
              <option value="">Selecione uma entidade...</option>
              {otherEntities.map(ent => (
                <option key={ent.id} value={ent.id}>{ent.name} ({ent.role || 'NPC'})</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-400 mb-1 block">Natureza da Relação</label>
            <input 
              list="relation-suggestions"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="ex: pertence a..."
              className="w-full bg-[#090D14] border border-slate-700 text-slate-300 text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-emerald-500/50 transition-colors"
            />
            <datalist id="relation-suggestions">
              {RELATION_SUGGESTIONS.map(sug => <option key={sug} value={sug} />)}
            </datalist>
          </div>

          <button 
            onClick={handleCreate}
            disabled={isCreating || !targetId || !label.trim()}
            className="w-full mt-1 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-medium py-2 rounded-lg text-sm transition-all disabled:opacity-50"
          >
            {isCreating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            Adicionar Conexão
          </button>
        </div>
      )}

      {/* Lista de Relações */}
      {isLoading ? (
        <div className="flex justify-center py-4"><Loader2 className="w-5 h-5 animate-spin text-emerald-500" /></div>
      ) : relations.length === 0 && !showForm ? (
        <p className="text-sm text-slate-500 italic bg-slate-900/30 p-3 rounded-lg border border-slate-800/50 text-center">Nenhuma conexão ainda.</p>
      ) : (
        <div className="flex flex-col gap-2">
          {relations.map(rel => {
            const isOutgoing = rel.from_entity_id === selectedCharacter;
            const linkedEntity = isOutgoing ? rel.to_entity : rel.from_entity;
            if (!linkedEntity) return null;

            return (
              <div 
                key={rel.id} 
                className={`flex items-start gap-3 p-3 rounded-xl border relative group transition-colors ${
                  isOutgoing 
                    ? 'bg-emerald-950/10 border-emerald-500/20 hover:border-emerald-500/40' 
                    : 'bg-slate-900/40 border-slate-700/50 hover:border-slate-600'
                }`}
              >
                <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 shrink-0 overflow-hidden flex items-center justify-center">
                  {linkedEntity.avatar_url ? (
                    <img src={linkedEntity.avatar_url} className="w-full h-full object-cover" alt="Avatar" />
                  ) : (
                    <User className="w-4 h-4 text-slate-500" />
                  )}
                </div>
                
                <div className="flex-1 min-w-0 pt-0.5">
                  <h4 className="text-sm font-medium text-slate-200 truncate">{linkedEntity.name}</h4>
                  <div className="flex items-center gap-1.5 mt-1">
                    {isOutgoing ? (
                      <ArrowRight className="w-3 h-3 text-emerald-500" />
                    ) : (
                      <ArrowLeft className="w-3 h-3 text-amber-500" />
                    )}
                    <span className={`text-xs truncate ${isOutgoing ? 'text-emerald-400/80' : 'text-amber-400/80'}`}>
                      {rel.relation_label}
                    </span>
                  </div>
                </div>

                <button 
                  onClick={() => handleDelete(rel.id)}
                  className="absolute right-2 top-2 p-1.5 rounded-md bg-rose-500/10 text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-rose-500/20"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}