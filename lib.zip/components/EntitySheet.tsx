'use client';

import React from 'react';
import { User, ImageIcon, Loader2, Save, CheckCircle2 } from 'lucide-react';
import { useWorldContext } from '../app/context/WorldContext';
import RichTextEditor from './RichTextEditor';

export default function EntitySheet() {
  const {
    selectedCharacter, currentCharacterData, charBio, setCharBio,
    avatarUrl, isUploading, isSavingChar,
    handleSaveCharacterInfo, handleAvatarUpload, fileInputRef,
  } = useWorldContext();

  const [saveSuccess, setSaveSuccess] = React.useState(false);

  const handleSave = async () => {
    await handleSaveCharacterInfo();
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  if (!selectedCharacter) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center border border-slate-800/50 rounded-2xl bg-slate-900/10 gap-4">
        <User className="w-12 h-12 text-slate-700" />
        <p className="text-slate-500 text-sm">Selecione uma entidade na lateral.</p>
      </div>
    );
  }

  return (
    <div className="flex-1 bg-[#0B1018] border border-slate-800/80 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
      {/* Header */}
      <div className="p-5 border-b border-slate-800 flex items-center gap-4 bg-slate-900/30">
        <div className="flex-1 flex items-center gap-3">
          <h2 className="text-2xl font-serif font-bold text-white">{currentCharacterData?.name}</h2>
          <span className="bg-emerald-500/10 px-2 py-0.5 rounded text-xs text-emerald-400 border border-emerald-500/20">
            Personagem
          </span>
        </div>
        <button
          onClick={handleSave}
          disabled={isSavingChar}
          className={`flex items-center gap-2 font-semibold px-4 py-1.5 rounded-lg text-sm transition-all disabled:opacity-50 ${saveSuccess
            ? 'bg-emerald-600 text-white shadow-[0_0_15px_rgba(16,185,129,0.3)]'
            : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-[0_0_15px_rgba(16,185,129,0.2)]'}`}
        >
          {isSavingChar
            ? <Loader2 className="w-4 h-4 animate-spin" />
            : saveSuccess
            ? <><CheckCircle2 className="w-4 h-4" /> Salvo!</>
            : <><Save className="w-4 h-4" /> Salvar</>
          }
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Editor */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
          <RichTextEditor
            key={selectedCharacter}
            initialContent={charBio}
            onChange={setCharBio}
          />
        </div>

        {/* Right Panel */}
        <div className="w-72 border-l border-slate-800 bg-[#090D14] overflow-y-auto custom-scrollbar p-5 flex flex-col gap-6">
          {/* Avatar */}
          <div>
            <p className="text-[10px] font-bold text-slate-500 tracking-wider mb-2 uppercase">Avatar</p>
            <div
              onClick={() => fileInputRef.current?.click()}
              className="w-full aspect-video rounded-xl border-2 border-dashed border-slate-700 bg-slate-900 flex flex-col items-center justify-center cursor-pointer hover:border-emerald-500/50 transition-all overflow-hidden relative group"
            >
              <input
                type="file"
                className="hidden"
                accept="image/*"
                ref={fileInputRef}
                onChange={handleAvatarUpload}
              />
              {isUploading
                ? <Loader2 className="w-6 h-6 text-emerald-500 animate-spin" />
                : avatarUrl
                ? <>
                    <img src={avatarUrl} className="w-full h-full object-cover group-hover:opacity-50 transition-opacity" alt="Avatar" />
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <span className="text-xs text-white bg-black/50 px-2 py-1 rounded">Trocar imagem</span>
                    </div>
                  </>
                : <>
                    <ImageIcon className="w-6 h-6 text-slate-500 mb-2" />
                    <span className="text-xs text-slate-400">Clique para adicionar</span>
                  </>
              }
            </div>
          </div>

          {/* Summary */}
          <div>
            <p className="text-[10px] font-bold text-slate-500 tracking-wider mb-3 uppercase">Resumo e Tags</p>
            <textarea
              placeholder="Breve descrição desta entidade..."
              className="w-full bg-slate-900/50 border border-slate-800 rounded-lg p-3 text-sm text-slate-300 focus:outline-none focus:border-emerald-500/50 resize-none h-24 mb-2 transition-all"
            />
            <button className="px-3 py-1 border border-dashed border-slate-700 text-slate-500 rounded-full text-xs hover:text-slate-300 hover:border-slate-500 transition-all">
              + Tag
            </button>
          </div>

          {/* Metadata */}
          <div>
            <p className="text-[10px] font-bold text-slate-500 tracking-wider mb-3 uppercase">Detalhes</p>
            <div className="space-y-2">
              {[
                ['Papel', currentCharacterData?.role],
                ['Raça', currentCharacterData?.race],
              ].map(([label, value]) => (
                <div key={label} className="flex justify-between text-xs">
                  <span className="text-slate-600">{label}</span>
                  <span className="text-slate-400">{value || '—'}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
